export type UserRole = "designer" | "student" | "company";
export interface User { id:string; name:string|null; email:string; image:string|null; role:UserRole; bio:string|null; location:string|null; hourlyRate:number|null; skills:string[]; createdAt:Date; }
export interface Project { id:string; title:string; description:string; tags:string[]; status:string; views:number; likes:number; userId:string; user?:User; createdAt:Date; }
export interface Post { id:string; title:string; body:string; category:string; tags:string[]; votes:number; views:number; solved:boolean; userId:string; user?:User; replies?:Reply[]; createdAt:Date; }
export interface Reply { id:string; body:string; votes:number; accepted:boolean; postId:string; userId:string; user?:User; createdAt:Date; }
export interface Product { id:string; name:string; brand:string; category:string; description:string; price:number; origPrice:number; discount:number; stock:number; icon:string; badge:string|null; rating:number; reviews:number; }
export interface CartItem { product:Product; quantity:number; }
export interface Job { id:string; title:string; company:string; location:string; type:string; pay:string; tags:string[]; description:string; requirements:string[]; remote:boolean; createdAt:Date; }
export interface ShippingAddress { name:string; email:string; phone:string; address:string; city:string; pin:string; state:string; }
export interface AIMessage { role:"user"|"assistant"; content:string; }