import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import JobsPageClient from "@/components/jobs/JobsPageClient";
export default async function JobsPage() {
  const session = await auth();
  const jobs = await prisma.job.findMany({ orderBy:{ createdAt:"desc" } });
  return <JobsPageClient jobs={jobs} userId={session!.user.id} />;
}