import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import Sidebar from "@/components/layout/Sidebar";
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session) redirect("/login");
  return (
    <div className="flex h-screen overflow-hidden" style={{ background:"var(--bg)" }}>
      <Sidebar user={session.user} />
      <main className="flex-1 overflow-hidden flex flex-col">{children}</main>
    </div>
  );
}