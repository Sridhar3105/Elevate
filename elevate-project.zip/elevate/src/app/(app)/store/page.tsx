import { prisma } from "@/lib/prisma";
import StorePageClient from "@/components/store/StorePageClient";
export default async function StorePage() {
  const products = await prisma.product.findMany({ orderBy:{ reviews:"desc" } });
  return <StorePageClient products={products} />;
}