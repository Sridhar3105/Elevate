import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
export default async function DashboardPage() {
  const session = await auth();
  const projects = await prisma.project.findMany({ where:{ userId:session!.user.id }, orderBy:{ updatedAt:"desc" }, take:5 });
  const feed = await prisma.post.findMany({ orderBy:{ createdAt:"desc" }, take:4, include:{ user:true } });
  return (
    <div className="fade-in p-8 flex-1 overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-black">Good morning, {session!.user.name?.split(" ")[0]} 👋</h1>
          <p style={{ color:"var(--muted)",fontSize:".85rem",marginTop:4 }}>Here's your overview for today.</p>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[{l:"Projects",v:projects.length,i:"🗂️"},{l:"Profile Views",v:"1.4K",i:"👁️"},{l:"Proposals",v:"7",i:"💼"},{l:"Course",v:"64%",i:"🎓"}].map(s=>(
          <div key={s.l} style={{ background:"var(--card)",border:"1px solid var(--border)",borderRadius:14,padding:"16px 18px" }}>
            <div className="flex justify-between">
              <div>
                <div style={{ color:"var(--muted)",fontSize:".72rem",fontWeight:600,marginBottom:6 }}>{s.l}</div>
                <div style={{ fontSize:"1.6rem",fontWeight:900 }}>{s.v}</div>
              </div>
              <span style={{ fontSize:"1.4rem" }}>{s.i}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="grid gap-4" style={{ gridTemplateColumns:"1.5fr 1fr" }}>
        <div style={{ background:"var(--card)",border:"1px solid var(--border)",borderRadius:14,padding:20 }}>
          <h2 className="font-black mb-4">My Projects</h2>
          {projects.map(p=>(
            <div key={p.id} style={{ display:"flex",alignItems:"center",gap:12,padding:"10px 12px",background:"var(--card2)",borderRadius:10,border:"1px solid var(--border)",marginBottom:8 }}>
              <div style={{ width:6,height:6,borderRadius:"50%",background:p.status==="published"?"#22c55e":p.status==="review"?"#f59e0b":"#7c6a9a",flexShrink:0 }}/>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:".85rem",fontWeight:700 }}>{p.title}</div>
                <div style={{ display:"flex",gap:4,marginTop:4 }}>{p.tags.slice(0,2).map(t=><span key={t} style={{ fontSize:".66rem",padding:"2px 7px",borderRadius:12,background:"rgba(168,85,247,.1)",border:"1px solid rgba(168,85,247,.2)",color:"var(--violet)" }}>{t}</span>)}</div>
              </div>
              <div style={{ fontSize:".68rem",color:"var(--muted)" }}>{p.status}</div>
            </div>
          ))}
        </div>
        <div style={{ background:"var(--card)",border:"1px solid var(--border)",borderRadius:14,padding:20 }}>
          <h2 className="font-black mb-4">Activity</h2>
          {feed.map((f,i)=>(
            <div key={i} style={{ display:"flex",gap:9,alignItems:"flex-start",marginBottom:13 }}>
              <div style={{ width:28,height:28,borderRadius:"50%",background:"linear-gradient(135deg,#e879f9,#7c3aed)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:".65rem",fontWeight:900,color:"#fff",flexShrink:0 }}>{f.user.name?.[0]??"U"}</div>
              <div><div style={{ fontSize:".79rem" }}><b>{f.user.name}</b> <span style={{ color:"var(--muted)" }}>posted in {f.category}</span></div><div style={{ fontSize:".65rem",color:"var(--muted)",marginTop:2 }}>{f.title.slice(0,40)}…</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}