import LibraryPageClient from "@/components/library/LibraryPageClient";
const COMPONENTS = [
  { id:"1",name:"STM32F103C8T6",mfr:"STMicro",cat:"MCU",pkg:"LQFP-48",sym:true,fp:true,m3d:true,spice:false,tools:["KiCad","Altium","Eagle"],rating:4.9,dls:8400 },
  { id:"2",name:"LM358",mfr:"Texas Instruments",cat:"Op-Amp",pkg:"SOIC-8",sym:true,fp:true,m3d:true,spice:true,tools:["KiCad","Altium","Eagle","Allegro"],rating:4.8,dls:12000 },
  { id:"3",name:"AMS1117-3.3",mfr:"Advanced Mono",cat:"LDO",pkg:"SOT-223",sym:true,fp:true,m3d:true,spice:true,tools:["KiCad","Altium"],rating:4.7,dls:9200 },
  { id:"4",name:"MPU-6050",mfr:"InvenSense",cat:"IMU",pkg:"QFN-24",sym:true,fp:true,m3d:true,spice:false,tools:["KiCad","Altium","Eagle"],rating:4.7,dls:11000 },
  { id:"5",name:"IRF540N",mfr:"Infineon",cat:"MOSFET",pkg:"TO-220",sym:true,fp:true,m3d:true,spice:true,tools:["KiCad","Altium","Eagle","Allegro"],rating:4.6,dls:6700 },
];
export default function LibraryPage() { return <LibraryPageClient components={COMPONENTS}/>; }