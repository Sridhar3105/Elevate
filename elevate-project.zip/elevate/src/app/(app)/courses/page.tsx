import CoursePageClient from "@/components/courses/CoursePageClient";
const LESSONS = [
  { id:"1",title:"Introduction to KiCad 7",duration:"12:04",free:true },
  { id:"2",title:"Setting Up Your Project",duration:"8:32",free:true },
  { id:"3",title:"Schematic Capture Basics",duration:"22:18",free:true },
  { id:"4",title:"Component Libraries",duration:"18:44",free:false },
  { id:"5",title:"Netlist & ERC Check",duration:"14:10",free:false },
  { id:"6",title:"PCB Layout Editor",duration:"28:56",free:false },
  { id:"7",title:"Routing Traces & Vias",duration:"31:22",free:false },
  { id:"8",title:"Design Rule Check",duration:"16:08",free:false },
  { id:"9",title:"Gerber Export",duration:"19:30",free:false },
];
export default function CoursesPage() { return <CoursePageClient lessons={LESSONS}/>; }