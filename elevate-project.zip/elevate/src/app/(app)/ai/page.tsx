"use client";
import { useState, useRef, useEffect } from "react";
import type { AIMessage } from "@/types";
export default function AIPage() {
  const [msgs, setMsgs] = useState<AIMessage[]>([{ role:"assistant", content:"👋 Hi! I'm Elevate AI — your expert PCB design co-pilot. Ask me anything or upload a schematic for review!" }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [file, setFile] = useState<File|null>(null);
  const [fileData, setFileData] = useState<string|null>(null);
  const [fileType, setFileType] = useState<string|null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => { bottom.current?.scrollIntoView({ behavior:"smooth" }); }, [msgs, loading]);
  function handleFile(f: File) {
    setFile(f);
    const reader = new FileReader();
    reader.onload = e => { setFileData((e.target!.result as string).split(",")[1]); setFileType(f.type); };
    reader.readAsDataURL(f);
  }
  async function send() {
    const q = input.trim(); if ((!q && !file) || loading) return;
    setInput("");
    const userMsg: AIMessage = { role:"user", content: q || "Please review this schematic: " + file?.name };
    const next = [...msgs, userMsg]; setMsgs(next); setLoading(true);
    try {
      const res = await fetch("/api/ai", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ messages: next, fileData, fileType }) });
      const data = await res.json();
      setMsgs(m => [...m, { role:"assistant", content: data.reply?.text || "No response." }]);
    } catch { setMsgs(m => [...m, { role:"assistant", content:"⚠️ Error. Please try again." }]); }
    setLoading(false); setFile(null); setFileData(null); setFileType(null);
  }
  return (
    <div style={{ flex:1,display:"flex",flexDirection:"column",height:"100vh",overflow:"hidden" }}>
      <div style={{ padding:"16px 26px",borderBottom:"1px solid var(--border)",background:"var(--card)",display:"flex",alignItems:"center",gap:12 }}>
        <div style={{ width:36,height:36,borderRadius:"50%",background:"linear-gradient(135deg,#e879f9,#7c3aed)",display:"flex",alignItems:"center",justifyContent:"center" }}>🤖</div>
        <div><div style={{ fontWeight:800 }}>Elevate AI</div><div style={{ fontSize:".7rem",color:"#22c55e" }}>● Hardware Expert · Schematic Review</div></div>
      </div>
      <div style={{ flex:1,overflowY:"auto",padding:"20px 26px",display:"flex",flexDirection:"column",gap:14 }}>
        {msgs.map((m,i) => (
          <div key={i} style={{ display:"flex",gap:10,flexDirection:m.role==="user"?"row-reverse":"row",alignItems:"flex-start" }}>
            <div style={{ width:30,height:30,borderRadius:"50%",background:m.role==="user"?"linear-gradient(135deg,#e879f9,#7c3aed)":"#1a0f2e",border:"1px solid var(--border)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:m.role==="user"?".7rem":"1rem",color:"#fff",flexShrink:0 }}>{m.role==="user"?"U":"🤖"}</div>
            <div style={{ maxWidth:"74%",background:m.role==="user"?"rgba(232,121,249,.08)":"var(--card)",border:"1px solid var(--border)",borderRadius:m.role==="user"?"18px 4px 18px 18px":"4px 18px 18px 18px",padding:"11px 14px",fontSize:".85rem",whiteSpace:"pre-wrap",lineHeight:1.65 }}>{m.content}</div>
          </div>
        ))}
        {loading && <div style={{ display:"flex",gap:10 }}><div style={{ width:30,height:30,borderRadius:"50%",background:"#1a0f2e",border:"1px solid var(--border)",display:"flex",alignItems:"center",justifyContent:"center" }}>🤖</div><div style={{ background:"var(--card)",border:"1px solid var(--border)",borderRadius:"4px 18px 18px 18px",padding:"13px 17px",display:"flex",gap:5,alignItems:"center" }}><div className="typing-dot"/><div className="typing-dot"/><div className="typing-dot"/></div></div>}
        <div ref={bottom}/>
      </div>
      {file && <div style={{ margin:"0 26px 8px",padding:"10px 14px",background:"rgba(168,85,247,.08)",border:"1px solid rgba(168,85,247,.25)",borderRadius:10,display:"flex",alignItems:"center",gap:10,fontSize:".82rem" }}><span>📎</span><span style={{ flex:1 }}>{file.name}</span><button onClick={()=>{ setFile(null);setFileData(null);}} style={{ background:"none",border:"none",color:"var(--muted)",cursor:"pointer" }}>✕</button></div>}
      <div style={{ padding:"10px 26px 20px",borderTop:"1px solid var(--border)" }}>
        <div style={{ display:"flex",gap:9 }}>
          <button onClick={()=>fileRef.current?.click()} style={{ padding:"10px 14px",borderRadius:10,border:"1px solid var(--border)",background:"transparent",color:"var(--muted)",cursor:"pointer",fontSize:"1rem" }}>📎</button>
          <input ref={fileRef} type="file" accept="image/*,application/pdf" style={{ display:"none" }} onChange={e=>e.target.files?.[0] && handleFile(e.target.files[0])}/>
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Ask about PCB design or upload a schematic…" style={{ flex:1,background:"var(--card2)",border:"1px solid var(--border)",borderRadius:10,padding:"10px 14px",color:"var(--text)",fontSize:".85rem",outline:"none" }}/>
          <button onClick={send} disabled={loading||(!input.trim()&&!file)} style={{ padding:"10px 18px",borderRadius:10,background:"linear-gradient(135deg,#e879f9,#7c3aed)",color:"#fff",border:"none",fontWeight:700,cursor:"pointer",opacity:(loading||(!input.trim()&&!file))?0.5:1 }}>{loading?"…":"Send"}</button>
        </div>
      </div>
    </div>
  );
}