import { prisma } from "@/lib/prisma";
import Link from "next/link";
export default async function ForumPage() {
  const posts = await prisma.post.findMany({ orderBy:{ createdAt:"desc" }, include:{ user:true, _count:{ select:{ replies:true } } } });
  const cats = ["All","PCB Design","Signal Integrity","Power Electronics","RF & Wireless","FPGA","Tools & EDA","Career"];
  return (
    <div className="fade-in flex-1 overflow-y-auto">
      <div style={{ padding:"16px 24px",borderBottom:"1px solid var(--border)",background:"var(--card)" }}>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
          <h1 style={{ fontWeight:900,fontSize:"1.05rem" }}>💬 Community Forum</h1>
          <button style={{ padding:"8px 16px",borderRadius:10,background:"linear-gradient(135deg,#e879f9,#7c3aed)",color:"#fff",border:"none",fontWeight:700,fontSize:".82rem",cursor:"pointer" }}>+ Ask Question</button>
        </div>
        <div style={{ display:"flex",gap:6,flexWrap:"wrap" }}>
          {cats.map(c=><button key={c} style={{ padding:"5px 12px",borderRadius:20,border:"1px solid var(--border)",background:"transparent",color:"var(--muted)",fontSize:".75rem",cursor:"pointer" }}>{c}</button>)}
        </div>
      </div>
      <div style={{ padding:"14px 20px" }}>
        {posts.map(p=>(
          <Link key={p.id} href={`/forum/${p.id}`} style={{ textDecoration:"none" }}>
            <div style={{ padding:"16px 18px",borderRadius:12,border:"1px solid var(--border)",background:"var(--card)",marginBottom:10,cursor:"pointer",display:"flex",gap:14,transition:".2s" }}>
              <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:3,width:40,flexShrink:0 }}>
                <div style={{ fontSize:".82rem",fontWeight:800,color:"var(--text)" }}>{p.votes}</div>
                <div style={{ fontSize:".62rem",color:"var(--muted)" }}>votes</div>
                <div style={{ fontSize:".82rem",fontWeight:700,color:p.solved?"#22c55e":"var(--muted)" }}>{p._count.replies}</div>
                <div style={{ fontSize:".62rem",color:p.solved?"#22c55e":"var(--muted)" }}>{p.solved?"solved":"ans"}</div>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700,fontSize:".9rem",color:"var(--text)",marginBottom:6 }}>{p.title}</div>
                <div style={{ display:"flex",gap:5,flexWrap:"wrap",marginBottom:8 }}>
                  <span style={{ fontSize:".68rem",padding:"2px 8px",borderRadius:10,background:"rgba(168,85,247,.1)",border:"1px solid rgba(168,85,247,.2)",color:"var(--violet)" }}>{p.category}</span>
                  {p.tags.slice(0,3).map(t=><span key={t} style={{ fontSize:".66rem",padding:"2px 7px",borderRadius:10,background:"rgba(168,85,247,.08)",color:"var(--muted)" }}>{t}</span>)}
                </div>
                <div style={{ fontSize:".73rem",color:"var(--muted)" }}>{p.user.name} · {new Date(p.createdAt).toLocaleDateString()} · {p.views} views</div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}