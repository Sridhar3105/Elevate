import Link from "next/link";
export default function LandingPage() {
  return (
    <div style={{ background: "var(--bg)", minHeight: "100vh" }}>
      <nav style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"16px 6%",position:"fixed",width:"100%",top:0,zIndex:100,background:"rgba(7,3,15,0.9)",backdropFilter:"blur(12px)",borderBottom:"1px solid var(--border)" }}>
        <div className="grad-text" style={{ fontSize:"1.4rem",fontWeight:900 }}>Elevate</div>
        <div style={{ display:"flex",gap:10 }}>
          <Link href="/login" style={{ padding:"8px 18px",borderRadius:8,border:"1px solid var(--border)",color:"var(--text)",fontWeight:600,fontSize:".88rem",textDecoration:"none" }}>Sign In</Link>
          <Link href="/login" style={{ padding:"9px 20px",borderRadius:8,background:"linear-gradient(135deg,#e879f9,#7c3aed)",color:"#fff",fontWeight:800,fontSize:".88rem",textDecoration:"none" }}>Join Free</Link>
        </div>
      </nav>
      <section style={{ minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"130px 6% 80px",position:"relative" }} className="pcb-grid">
        <div style={{ maxWidth:820,position:"relative",zIndex:2 }}>
          <div style={{ display:"inline-block",background:"rgba(168,85,247,.1)",border:"1px solid rgba(168,85,247,.3)",color:"var(--pink)",padding:"7px 18px",borderRadius:24,fontSize:".78rem",fontWeight:700,marginBottom:26 }}>⚡ Built for Hardware Engineers</div>
          <h1 style={{ fontSize:"clamp(2.4rem,5.5vw,4rem)",fontWeight:900,lineHeight:1.08,marginBottom:22 }}>
            The Platform That<br/><span className="grad-text">Elevates Hardware</span><br/>Designers
          </h1>
          <p style={{ fontSize:"1.1rem",color:"var(--muted)",maxWidth:580,margin:"0 auto 38px",lineHeight:1.75 }}>
            Showcase PCB projects, freelance with top companies, learn from experts, simulate circuits, shop components, and harness AI — all in one place.
          </p>
          <div style={{ display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap" }}>
            <Link href="/login" style={{ padding:"14px 32px",borderRadius:9,background:"linear-gradient(135deg,#e879f9,#7c3aed)",color:"#fff",fontWeight:800,fontSize:"1rem",textDecoration:"none",boxShadow:"0 0 24px rgba(168,85,247,.4)" }}>🚀 Get Started Free</Link>
            <Link href="/dashboard" style={{ padding:"14px 32px",borderRadius:9,border:"1px solid var(--border)",color:"var(--text)",fontWeight:600,fontSize:"1rem",textDecoration:"none" }}>View Demo →</Link>
          </div>
        </div>
      </section>
    </div>
  );
}