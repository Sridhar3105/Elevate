import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { z } from "zod";
const Schema = z.object({ title:z.string().min(10), body:z.string().min(20), category:z.string(), tags:z.array(z.string()).max(5) });
export async function GET(req: NextRequest) {
  const cat = new URL(req.url).searchParams.get("category");
  const posts = await prisma.post.findMany({ where:cat?{ category:cat }:undefined, orderBy:{ createdAt:"desc" }, include:{ user:{ select:{ id:true,name:true,image:true } }, _count:{ select:{ replies:true } } } });
  return NextResponse.json(posts);
}
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error:"Unauthorized" }, { status:401 });
  const data = Schema.parse(await req.json());
  const post = await prisma.post.create({ data:{ ...data, userId:session.user.id } });
  return NextResponse.json(post, { status:201 });
}