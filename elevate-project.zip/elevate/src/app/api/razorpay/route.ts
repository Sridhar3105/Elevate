import { NextRequest, NextResponse } from "next/server";
import Razorpay from "razorpay";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
const rzp = new Razorpay({ key_id:process.env.RAZORPAY_KEY_ID!, key_secret:process.env.RAZORPAY_KEY_SECRET! });
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error:"Unauthorized" }, { status:401 });
  const { items, address } = await req.json();
  const subtotal = items.reduce((s: number, i: any) => s + i.price * i.quantity, 0);
  const total = subtotal + (subtotal > 500 ? 0 : 49);
  const rzpOrder = await rzp.orders.create({ amount:Math.round(total*100), currency:"INR", receipt:`elv_${Date.now()}` });
  const order = await prisma.order.create({ data:{ userId:session.user.id, total, razorpayId:rzpOrder.id, address, items:{ create:items.map((i: any) => ({ productId:i.productId, quantity:i.quantity, price:i.price })) } } });
  return NextResponse.json({ orderId:rzpOrder.id, amount:rzpOrder.amount, dbOrderId:order.id, keyId:process.env.RAZORPAY_KEY_ID });
}