import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { auth } from "@/lib/auth";
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error:"Unauthorized" }, { status:401 });
  const { messages, fileData, fileType } = await req.json();
  const lastContent: any[] = [];
  if (fileData && fileType) {
    if (fileType === "application/pdf") lastContent.push({ type:"document", source:{ type:"base64", media_type:"application/pdf", data:fileData } });
    else lastContent.push({ type:"image", source:{ type:"base64", media_type:fileType, data:fileData } });
  }
  lastContent.push({ type:"text", text: messages.at(-1)?.content || "Review this schematic." });
  const history = messages.slice(0,-1).map((m: any) => ({ role:m.role, content:m.content }));
  const response = await client.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1024,
    system: "You are Elevate AI, an expert hardware engineering assistant specialised in PCB design, circuit analysis, component selection, signal integrity, power electronics, EMC/EMI, FPGA, and EDA tools (KiCad, Altium, Eagle). Be concise, practical, and expert-level.",
    messages: [...history, { role:"user", content:lastContent }],
  });
  return NextResponse.json({ reply: response.content[0] });
}