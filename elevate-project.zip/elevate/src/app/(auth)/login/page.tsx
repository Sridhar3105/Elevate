"use client";
import { signIn } from "next-auth/react";
import Link from "next/link";
export default function LoginPage() {
  return (
    <div style={{ minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",padding:24,background:"var(--bg)" }}>
      <div style={{ width:"100%",maxWidth:420,background:"var(--card)",border:"1px solid var(--border)",borderRadius:20,padding:40 }}>
        <div style={{ textAlign:"center",marginBottom:28 }}>
          <div className="grad-text" style={{ fontSize:"1.8rem",fontWeight:900,marginBottom:6 }}>Elevate</div>
          <p style={{ color:"var(--muted)",fontSize:".9rem" }}>Welcome back, engineer 👋</p>
        </div>
        <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
          {[{ p:"google",l:"🔵 Continue with Google" },{ p:"github",l:"⬛ Continue with GitHub" }].map(({ p,l }) => (
            <button key={p} onClick={() => signIn(p, { callbackUrl:"/dashboard" })}
              style={{ width:"100%",padding:"13px",borderRadius:10,border:"1px solid var(--border)",background:"transparent",color:"var(--text)",fontWeight:600,fontSize:".88rem",cursor:"pointer",transition:".2s" }}>{l}</button>
          ))}
        </div>
        <p style={{ textAlign:"center",marginTop:20,color:"var(--muted)",fontSize:".82rem" }}>
          Don't have an account?{" "}
          <Link href="/login" style={{ color:"var(--pink)",fontWeight:700 }}>Sign up free</Link>
        </p>
      </div>
    </div>
  );
}