import { type ClassValue, clsx } from "clsx";
export function cn(...inputs: ClassValue[]) { return clsx(inputs); }
export function formatPrice(amount: number, currency = "INR") {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency, maximumFractionDigits: 0 }).format(amount);
}
export function timeAgo(date: Date | string) {
  const s = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}
export function truncate(str: string, len: number) {
  return str.length > len ? str.slice(0, len) + "…" : str;
}