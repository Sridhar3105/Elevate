// NOTE: Client components (StorePageClient, JobsPageClient, LibraryPageClient,
// CoursePageClient, etc.) should be created in src/components/ based on
// the Elevate App UI prototype. These are the interactive "use client"
// wrappers around the server page data. See the Elevate App artifact
// for the full component code to copy into each file.