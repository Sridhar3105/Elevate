"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
const NAV = [
  { href:"/dashboard",icon:"⬡",label:"Dashboard" },
  { href:"/profile",icon:"👤",label:"My Profile" },
  { href:"/ai",icon:"🤖",label:"AI Assistant" },
  { href:"/courses",icon:"🎓",label:"Courses" },
  { href:"/store",icon:"🛒",label:"Store" },
  { href:"/library",icon:"📦",label:"Library" },
  { href:"/jobs",icon:"💼",label:"Jobs" },
  { href:"/forum",icon:"💬",label:"Community" },
];
export default function Sidebar({ user }: { user: any }) {
  const path = usePathname();
  return (
    <div style={{ width:218,background:"var(--card)",borderRight:"1px solid var(--border)",display:"flex",flexDirection:"column",padding:"0 10px 20px",flexShrink:0 }}>
      <div style={{ padding:"18px 8px 20px",borderBottom:"1px solid var(--border)",marginBottom:10 }}>
        <div className="grad-text" style={{ fontSize:"1.4rem",fontWeight:900 }}>Elevate</div>
        <div style={{ fontSize:".66rem",color:"var(--muted)",marginTop:1 }}>Hardware Design Platform</div>
      </div>
      {NAV.map(item => {
        const active = path.startsWith(item.href);
        return (
          <Link key={item.href} href={item.href} style={{ display:"flex",alignItems:"center",gap:11,padding:"10px 13px",borderRadius:11,fontSize:".85rem",fontWeight:active?700:500,color:active?"var(--pink)":"var(--muted)",background:active?"rgba(168,85,247,.14)":"transparent",textDecoration:"none",transition:".15s",borderLeft:active?"2px solid var(--pink)":"2px solid transparent",marginBottom:2 }}>
            <span style={{ fontSize:"1rem" }}>{item.icon}</span>{item.label}
          </Link>
        );
      })}
      <div style={{ marginTop:"auto",padding:12,background:"rgba(168,85,247,.07)",borderRadius:12,border:"1px solid var(--border)" }}>
        <div style={{ display:"flex",alignItems:"center",gap:9,marginBottom:10 }}>
          <div style={{ width:30,height:30,borderRadius:"50%",background:"linear-gradient(135deg,#e879f9,#7c3aed)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:".75rem",color:"#fff" }}>{user?.name?.[0]??"U"}</div>
          <div><div style={{ fontSize:".8rem",fontWeight:700 }}>{user?.name??"User"}</div><div style={{ fontSize:".66rem",color:"var(--muted)" }}>PCB Designer</div></div>
        </div>
        <button onClick={()=>signOut({ callbackUrl:"/login" })} style={{ width:"100%",padding:"6px 0",borderRadius:8,border:"1px solid var(--border)",background:"transparent",color:"var(--muted)",fontSize:".75rem",cursor:"pointer" }}>Sign Out</button>
      </div>
    </div>
  );
}