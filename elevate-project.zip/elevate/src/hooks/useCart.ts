import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartItem, Product } from "@/types";
interface CartStore {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQty: (productId: string, qty: number) => void;
  clearCart: () => void;
  total: () => number;
}
export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      cart: [],
      addToCart: (product) => {
        const ex = get().cart.find(i => i.product.id === product.id);
        if (ex) set(s => ({ cart: s.cart.map(i => i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i) }));
        else set(s => ({ cart: [...s.cart, { product, quantity: 1 }] }));
      },
      removeFromCart: (id) => set(s => ({ cart: s.cart.filter(i => i.product.id !== id) })),
      updateQty: (id, qty) => set(s => ({ cart: s.cart.map(i => i.product.id === id ? { ...i, quantity: qty } : i) })),
      clearCart: () => set({ cart: [] }),
      total: () => get().cart.reduce((s, i) => s + i.product.price * 84 * i.quantity, 0),
    }),
    { name: "elevate-cart" }
  )
);