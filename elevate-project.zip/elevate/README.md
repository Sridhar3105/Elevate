# Elevate – Hardware Design Platform

Full-stack Next.js 15 platform for PCB designers.

## Quick Start

```bash
git clone https://github.com/YOUR_USERNAME/elevate.git
cd elevate
npm install
cp .env.example .env.local
# Fill in .env.local values
npx prisma generate
npx prisma db push
npm run dev
```

Open http://localhost:3000

## Stack
- Next.js 15 + TypeScript + Tailwind CSS
- NextAuth v5 (Google, GitHub)
- PostgreSQL (Supabase) + Prisma ORM
- Anthropic Claude AI
- Razorpay Payments
- Vercel Hosting

## Deploy
```bash
npm i -g vercel && vercel --prod
```
