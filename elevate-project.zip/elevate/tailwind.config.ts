import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        bg: "#07030f", card: "#110a1f", card2: "#0e0819",
        border: "#2d1f45", pink: "#e879f9", violet: "#a855f7",
        purple: "#7c3aed", muted: "#7c6a9a",
      },
    },
  },
  plugins: [],
};
export default config;